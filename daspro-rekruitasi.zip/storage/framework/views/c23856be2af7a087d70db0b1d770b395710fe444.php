<?php $__env->startSection('title','Nilai'); ?>
<?php $__env->startSection('nilai','active'); ?>
<?php $__env->startSection('container'); ?>

    <div class="text-center mt-5 mb-5">
        <h2>Login</h2>
    </div>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('asisten_verif_data')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="kode_asisten">Kode Asisten</label>
                    <input type="text" class="form-control" name="kode_asisten" id="kode_asisten">
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="number" class="form-control" name="password" id="password" required>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Login</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\htdocs\rekruitasidaspro\resources\views/asisten/landing.blade.php ENDPATH**/ ?>