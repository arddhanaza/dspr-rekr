<?php $__env->startSection('title','Nilai'); ?>
<?php $__env->startSection('nilai','active'); ?>
<?php echo $__env->make('template.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('container'); ?>

    <div class="text-center mt-5">
        <h2>Daftar Nilai Basdat</h2>
    </div>
    <div class="card">
        <div class="card-body">
            <table class="table mt-3 datTable">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Nama Calon Asisten</th>
                    <th>Kode Asisten Penilai</th>
                    <th>Administasi</th>
                    <th>CBT Test</th>
                    <th>Hackerrank</th>
                    <th>Microteaching</th>
                    <th>Interview</th>
                    <th>Total</th>
                    <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $nilai_caas_basdat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->index+1); ?></td>
                        <td><?php echo e($caas->nama_caas); ?></td>
                        <td><?php echo e($caas->kode_asisten); ?></td>
                        <td><?php echo e($caas->Administrasi); ?></td>
                        <td><?php echo e($caas->CBTTest); ?></td>
                        <td><?php echo e($caas->Hackerrank); ?></td>
                        <td><?php echo e($caas->Microteaching); ?></td>
                        <td><?php echo e($caas->Interview); ?></td>
                        <td><?php echo e($caas->Total); ?></td>
                        <td>
                            <a href="<?php echo e(route('add_nilai_microteaching',$caas->id_caas)); ?>" class="btn btn-secondary mb-3">Add Nilai Microteaching</a>
                            <a href="<?php echo e(route('asisten_edit_nilai',$caas->id_caas)); ?>" class="btn btn-outline-secondary">Edit</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="text-center mt-5">
        <h2>Daftar Nilai Alpro</h2>
    </div>
    <div class="card">
        <div class="card-body">
            <table class="table mt-3 datTable">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Nama Calon Asisten</th>
                    <th>Kode Asisten Penilai</th>
                    <th>Administasi</th>
                    <th>CBT Test</th>
                    <th>Hackerrank</th>
                    <th>Microteaching</th>
                    <th>Interview</th>
                    <th>Total</th>
                    <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $nilai_caas_alpro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->index+1); ?></td>
                        <td><?php echo e($caas->nama_caas); ?></td>
                        <td><?php echo e($caas->kode_asisten); ?></td>
                        <td><?php echo e($caas->Administrasi); ?></td>
                        <td><?php echo e($caas->CBTTest); ?></td>
                        <td><?php echo e($caas->Hackerrank); ?></td>
                        <td><?php echo e($caas->Microteaching); ?></td>
                        <td><?php echo e($caas->Interview); ?></td>
                        <td><?php echo e($caas->Total); ?></td>
                        <td>
                            <a href="<?php echo e(route('asisten_edit_nilai',$caas->id_caas)); ?>" class="btn btn-primary">Edit</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\htdocs\rekruitasidaspro\resources\views/asisten/index.blade.php ENDPATH**/ ?>