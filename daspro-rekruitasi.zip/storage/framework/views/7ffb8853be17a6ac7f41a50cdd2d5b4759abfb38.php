<nav class="navbar navbar-expand navbar-light bg-transparent justify-content-center">
    <ul class="navbar-nav">
        <?php if(session('status') == 'caas'): ?>
            <?php if(false): ?>
                <li class="nav-item <?php echo $__env->yieldContent('nilai_akhir'); ?>">
                    <a class="nav-link" href="<?php echo e(route('caas_lihat_nilai')); ?>"><strong>NILAI AKHIR</strong></a>
                </li>
            <?php endif; ?>
            <li class="nav-item <?php echo $__env->yieldContent('lihat_nilai'); ?>">
                <a class="nav-link" href="<?php echo e(route('caas_lihat_nilai_by_id',session(0)->id_caas)); ?>"><strong>LIHAT
                        NILAI</strong></a>
            </li>
        <?php else: ?>
            <li class="nav-item <?php echo $__env->yieldContent('nilai'); ?>">
                <a class="nav-link" href="<?php echo e(route('asisten_lihat_nilai')); ?>"><strong>NILAI</strong></a>
            </li>
        <?php endif; ?>
        <li class="nav-item <?php echo $__env->yieldContent('exit'); ?>">
            <a class="nav-link" href="<?php echo e(route('logout')); ?>"><strong>EXIT</strong></a>
        </li>
    </ul>
</nav>
<?php /**PATH D:\Project\htdocs\rekruitasidaspro\resources\views/template/navbar.blade.php ENDPATH**/ ?>